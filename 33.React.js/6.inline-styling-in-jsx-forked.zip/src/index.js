import React from "react";
import ReactDOM from "react-dom";

const customStyle = {
  color: "blue",
  fontSize: "60px",
  border: "2px solid red"
};

customStyle.border = "9px dotted pink";
customStyle.padding = "20px";

ReactDOM.render(
  // <h1 style={{ color: "red" }}> Yolo !</h1>,
  <h1 style={customStyle}> Yolo !</h1>,
  document.getElementById("root")
);
