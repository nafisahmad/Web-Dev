import React from "react";
import Heading from "./Components/Heading";

function App() {
  return (
    <div>
      <Heading />
    </div>
  );
}

export default App;
