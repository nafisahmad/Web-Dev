import React, { useState } from "react";

function App() {
  // 1st Method-------
  // const [fName, setFName] = useState("");
  // const [lName, setLName] = useState();

  // 1st Method-------
  // function updateFName(event) {
  //   const firstName = event.target.value;
  //   setFName(firstName);
  // }
  // function updateLName(event) {
  //   const lastName = event.target.value;
  //   setLName(lastName);
  // }

  // 2nd Method----
  const [fullName, setFullName] = useState({
    fName: "",
    lName: ""
  });
  // console.log(fullName.fName, fullName.lName);

  function handleChange(event) {
    const newValue = event.target.value;
    const inputName = event.target.name;

    // console.log(newValue);
    // console.log(inputName);

    // if (inputName === "fName") {
    //   setFullName({ fName: newValue });
    // } else if (inputName === "lName") {
    //   setFullName({ lName: newValue });
    // }

    setFullName((prevValue) => {
      // console.log(prevValue);
      if (inputName === "fName") {
        return {
          fName: newValue,
          lName: prevValue.lName
        };
      } else if (inputName === "lName") {
        return {
          fName: prevValue.fName,
          lName: newValue
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        {/* Hello {fName} {lName} */}
        Hello {fullName.fName} {fullName.lName}
      </h1>

      <form>
        <input
          name="fName"
          // onChange={updateFName}
          onChange={handleChange}
          placeholder="First Name"
          value={fullName.fName}
        />

        <input
          name="lName"
          onChange={handleChange}
          placeholder="Last Name"
          value={fullName.lName}
        />

        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
