import React from "react";
import ReactDOM from "react-dom";

// import Heading from "./Heading";
// import List from "./List";
import App from "./App";

ReactDOM.render(
  // <div>
  //   {/* <Heading> </Heading> */}
  //   <Heading />
  //   <List />
  // </div>,
  // document.getElementById("root")
  <div>
    <App />
  </div>,
  document.getElementById("root")
);
