import React from "react";
import Login from "./Login";

var isLoggedIn = false;

// function renderConditionalally() {
//   if (isLoggedIn === true) {
//     return <h1>Hello</h1>;
//   } else {
//     return (
//       // <form className="form">
//       //   <input type="text" placeholder="Username" />
//       //   <input type="password" placeholder="Password" />
//       //   <button type="submit">Login</button>
//       // </form>
//       <Login />
//     );
//   }
// }

const currentTime = new Date().getHours();
console.log(currentTime);

function App() {
  // return <div className="container"> {renderConditionalally()} </div>;
  return (
    <div className="container">
      {
        // isLoggedIn ? <h1>Hello</h1> : <Login />

        // currentTime > 16 ? <h1>Why are you still here ?</h1> : null
        currentTime > 12 && <h1>Why are you still here ?</h1>
      }
    </div>
  );
}

export default App;
