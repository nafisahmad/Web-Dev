const pi = 3.141596;

function doublepi() {
  return pi * 2;
}

function triplepi() {
  return pi * 3;
}

export default pi;
export { doublepi, triplepi };
