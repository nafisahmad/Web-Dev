const animals = [
  {
    name: "cat",
    sound: "meow",
    feedingRequirements: {
      food: 5,
      water: 7
    }
  },
  { name: "dog", sound: "woof" }
];

export default animals;
