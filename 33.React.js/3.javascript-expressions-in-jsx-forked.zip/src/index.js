import React from "react";
import ReactDOM from "react-dom";

const fname = "Nafis";
const lname = "Ahmad";
const luckyNumber = 4;

ReactDOM.render(
  <div>
    <h1>Hello {fname + " " + lname}!</h1>
    <h1>
      Hello {fname} {lname}!
    </h1>
    <h1>Hello {`${fname} ${lname}`}!</h1>
    <p>Your Lucky Number is : {luckyNumber}</p>
    <p>Your Second Lucky Number is : {8 + 1}</p>
    <p>Your other Lucky Number is : {Math.floor(Math.random() * 10)}</p>
  </div>,
  document.getElementById("root")
);
