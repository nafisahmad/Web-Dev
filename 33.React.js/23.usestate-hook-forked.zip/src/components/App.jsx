// import React, { useState } from "react";

// // var count = 0;

// function App() {
//   // const state = useState(234);
//   const [count, setCount] = useState(1000);

//   function increase() {
//     // count++;
//     // console.log(count);

//     // setCount(12);
//     setCount(count + 1);
//   }

//   function decrease() {
//     setCount(count - 1);
//   }

//   return (
//     <div className="container">
//       <h1>{count}</h1>
//       <button onClick={increase}>+</button>
//       <button onClick={decrease}>-</button>
//     </div>
//   );
// }

// export default App;

import React, { useState } from "react";

function App() {
  const [count, setCount] = useState(100);

  function increase() {
    setCount(count + 1);
  }
  function decrease() {
    setCount(count - 1);
  }

  return (
    <div className="container">
      <h1>{count}</h1>
      <button onClick={increase}>+</button>
      <button onClick={decrease}>-</button>
    </div>
  );
}

export default App;
